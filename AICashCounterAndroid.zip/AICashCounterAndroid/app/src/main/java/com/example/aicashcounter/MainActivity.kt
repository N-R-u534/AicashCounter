package com.example.aicashcounter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val denominations = listOf(500, 200, 100, 50, 20, 10, 5, 2, 1)
    private val counts = mutableMapOf<Int, Int>()
    private val countInputs = mutableMapOf<Int, EditText>()
    private lateinit var totalText: TextView
    private lateinit var piecesText: TextView
    private lateinit var wordsText: TextView
    private lateinit var extraInput: EditText
    private lateinit var statusText: TextView
    private var extra = 0.0
    private val prefs by lazy { getSharedPreferences("cash_counter", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        denominations.forEach { counts[it] = 0 }
        buildScreen()
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFF17251E.toInt())
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F7F4.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            setBackgroundColor(0xFF0D5C3D.toInt())
        }
        header.addView(TextView(this).apply {
            text = "₹  AI CASH COUNTER"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
        })
        header.addView(TextView(this).apply {
            text = "INDIA  •  Instant cash total"
            textSize = 12f
            setTextColor(0xFFD6F1E2.toInt())
        })
        page.addView(header)

        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        summary.addView(label("GRAND TOTAL", 12f, true))
        totalText = label("₹0", 34f, true).apply { setTextColor(0xFF0D5C3D.toInt()) }
        summary.addView(totalText)
        piecesText = label("0 pieces", 14f)
        summary.addView(piecesText)
        wordsText = label("Zero Rupees", 13f).apply { setPadding(0, dp(6), 0, 0) }
        summary.addView(wordsText)
        body.addView(summary)

        body.addView(label("DENOMINATIONS  •  ₹1 TO ₹500", 13f, true).apply {
            setPadding(dp(2), dp(20), 0, dp(8))
        })
        denominations.forEach { value ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(9), dp(8), dp(9))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val denom = label("₹$value", 18f, true)
            row.addView(denom, LinearLayout.LayoutParams(0, dp(48), 1f))
            val minus = button("−") { setCount(value, (counts[value] ?: 0) - 1) }
            row.addView(minus, LinearLayout.LayoutParams(dp(42), dp(42)))
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText("0")
                textSize = 17f
                gravity = Gravity.CENTER
                setPadding(dp(2), 0, dp(2), 0)
                setSelectAllOnFocus(true)
                filters = arrayOf(android.text.InputFilter.LengthFilter(7))
                addTextChangedListener(SimpleWatcher {
                    val n = it.toIntOrNull() ?: 0
                    counts[value] = n.coerceIn(0, 999999)
                    refresh()
                })
            }
            countInputs[value] = input
            row.addView(input, LinearLayout.LayoutParams(dp(74), dp(44)))
            row.addView(button("+") { setCount(value, (counts[value] ?: 0) + 1) },
                LinearLayout.LayoutParams(dp(42), dp(42)))
            val clear = button("×") { setCount(value, 0) }
            row.addView(clear, LinearLayout.LayoutParams(dp(38), dp(42)))
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(2), 0, dp(2))
                addView(row)
            }
            body.addView(outer)
        }

        body.addView(label("EXTRA AMOUNT / CALCULATOR RESULT", 12f, true).apply {
            setPadding(dp(2), dp(18), 0, dp(6))
        })
        extraInput = EditText(this).apply {
            hint = "Enter extra amount (₹)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText("0")
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
            addTextChangedListener(SimpleWatcher {
                extra = (it.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
                refresh()
            })
        }
        body.addView(extraInput)

        val buttons1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons1.addView(button("Save count") { saveCount() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons1.addView(button("History") { showHistory() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        body.addView(buttons1)
        val buttons2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons2.addView(button("Export receipt") { exportReceipt() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons2.addView(button("Copy total") { copyTotal() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        body.addView(buttons2)
        body.addView(button("Clear all") { clearAll() }.apply {
            setBackgroundColor(0xFFFFE8E5.toInt())
            setTextColor(0xFF9D3025.toInt())
        })
        body.addView(button("AI note scan — not configured") {
            AlertDialog.Builder(this)
                .setTitle("AI note recognition")
                .setMessage("The reference document's scan button only inserts random demo counts. It does not contain a trained banknote-recognition model. This app therefore does not pretend to identify notes from a photo. A real AI scan needs a trained model and sample note images.")
                .setPositiveButton("OK", null).show()
        })
        statusText = label("₹2,000 denomination is excluded, as specified in the reference.", 11f)
        statusText.setTextColor(0xFF64746A.toInt())
        statusText.setPadding(dp(4), dp(12), dp(4), 0)
        body.addView(statusText)
        scroll.addView(body)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 13f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun setCount(value: Int, count: Int) {
        val n = count.coerceIn(0, 999999)
        counts[value] = n
        countInputs[value]?.setText(n.toString())
        countInputs[value]?.setSelection(countInputs[value]?.text?.length ?: 1)
        refresh()
    }

    private fun refresh() {
        val pieces = counts.values.sum()
        val notesTotal = denominations.sumOf { it.toLong() * (counts[it] ?: 0) }
        val total = notesTotal + extra
        totalText.text = "₹" + String.format(Locale("en", "IN"), "%,.2f", total).removeSuffix(".00")
        piecesText.text = "$pieces pieces  •  Notes & coins subtotal ₹${String.format(Locale("en", "IN"), "%,.0f", notesTotal.toDouble())}  •  Extra ₹${String.format(Locale("en", "IN"), "%,.2f", extra)}"
        wordsText.text = numberToWords(total.toLong()) + " Rupees"
    }

    private fun saveCount() {
        val total = denominations.sumOf { it.toLong() * (counts[it] ?: 0) } + extra
        if (total <= 0) {
            Toast.makeText(this, "Add some cash first", Toast.LENGTH_SHORT).show()
            return
        }
        val record = JSONObject().apply {
            put("date", SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date()))
            put("total", total)
            put("pieces", counts.values.sum())
            put("counts", JSONObject().apply { denominations.forEach { put(it.toString(), counts[it] ?: 0) } })
            put("extra", extra)
            put("words", numberToWords(total.toLong()) + " Rupees")
        }
        val history = JSONArray(prefs.getString("history", "[]"))
        history.put(record)
        prefs.edit().putString("history", history.toString()).apply()
        Toast.makeText(this, "Count saved on this device", Toast.LENGTH_SHORT).show()
    }

    private fun showHistory() {
        val history = JSONArray(prefs.getString("history", "[]"))
        if (history.length() == 0) {
            AlertDialog.Builder(this).setTitle("History").setMessage("No saved counts yet.")
                .setPositiveButton("OK", null).show()
            return
        }
        val lines = (history.length() - 1 downTo 0).map { i ->
            val r = history.getJSONObject(i)
            "${r.optString("date")}\\n₹${String.format(Locale("en", "IN"), "%,.2f", r.optDouble("total"))} • ${r.optInt("pieces")} pieces"
        }
        AlertDialog.Builder(this).setTitle("Saved cash counts")
            .setItems(lines.toTypedArray(), null)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear history") { _, _ -> prefs.edit().remove("history").apply() }
            .show()
    }

    private fun receipt(): String {
        val total = denominations.sumOf { it.toLong() * (counts[it] ?: 0) } + extra
        return buildString {
            append("AI CASH COUNTER — INDIA\\n")
            append("Date: ${SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())}\\n")
            append("--------------------------------\\n")
            denominations.forEach { v ->
                val n = counts[v] ?: 0
                if (n > 0) append("₹$v x $n = ₹${v.toLong() * n}\\n")
            }
            if (extra > 0) append("Extra: ₹$extra\\n")
            append("--------------------------------\\n")
            append("Total pieces: ${counts.values.sum()}\\n")
            append("Grand total: ₹${String.format(Locale("en", "IN"), "%,.2f", total)}\\n")
            append("In words: ${numberToWords(total.toLong())} Rupees\\n")
            append("₹2,000 denomination excluded as specified in reference.\\n")
        }
    }

    private fun exportReceipt() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "cash-receipt-${System.currentTimeMillis()}.txt")
        }
        pendingReceipt = receipt()
        startActivityForResult(intent, 42)
    }

    private var pendingReceipt = ""
    @Deprecated("Use Activity Result APIs in a future update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingReceipt) }
                Toast.makeText(this, "Receipt exported", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun copyTotal() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val total = denominations.sumOf { it.toLong() * (counts[it] ?: 0) } + extra
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Cash total", "₹$total — ${numberToWords(total.toLong())} Rupees"))
        Toast.makeText(this, "Total copied", Toast.LENGTH_SHORT).show()
    }

    private fun clearAll() {
        denominations.forEach { counts[it] = 0; countInputs[it]?.setText("0") }
        extraInput.setText("0")
        extra = 0.0
        refresh()
    }

    private fun numberToWords(input: Long): String {
        if (input == 0L) return "Zero"
        if (input < 0) return "Invalid"
        val small = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
        val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")
        fun under100(n: Int): String = if (n < 20) small[n] else tens[n / 10] + if (n % 10 > 0) " " + small[n % 10] else ""
        fun under1000(n: Int): String {
            val h = n / 100
            val r = n % 100
            return (if (h > 0) small[h] + " Hundred" else "") +
                (if (h > 0 && r > 0) " " else "") + if (r > 0) under100(r) else ""
        }
        var n = input
        val parts = mutableListOf<String>()
        val crore = n / 10000000; n %= 10000000
        val lakh = n / 100000; n %= 100000
        val thousand = n / 1000; n %= 1000
        if (crore > 0) parts.add(under1000(crore.toInt()) + " Crore")
        if (lakh > 0) parts.add(under1000(lakh.toInt()) + " Lakh")
        if (thousand > 0) parts.add(under1000(thousand.toInt()) + " Thousand")
        if (n > 0) parts.add(under1000(n.toInt()))
        return parts.joinToString(" ")
    }

    private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
